export class ArtifactoryModel {
  public id: number;
  public artifactoryName: string;
}
