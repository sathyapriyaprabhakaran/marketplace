export class Pagination {
    public itemsPerPage: number;
    public currentPage: number;
    public totalItems: number;
    public id?: number;
}