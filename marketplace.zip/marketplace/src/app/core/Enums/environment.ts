export enum Environment {
    Prod = 'prod',
    Staging = 'staging',
    Test = 'test',
    Dev = 'dev',
    Local = 'local'
}