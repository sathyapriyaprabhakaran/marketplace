export class PermissionModel {
  permissionId: number;
  permissionName: string;
  permissionDescription: string;
}
