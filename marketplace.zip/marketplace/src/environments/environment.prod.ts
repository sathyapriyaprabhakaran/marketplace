export const environment = {
    production: true,
    //baseUrl: 'http://gb1d9035018.eu.hedani.net:8080/marketplace-2.4.2'
    // baseUrl: 'http://gb1d9035018.eu.hedani.net:8090/marketplacedev'
    // baseUrl: 'http://localhost:8080/marketplace-2.4.2'
    baseUrl: 'http://desops.eastus2.cloudapp.azure.com:8080/marketplace-2.4.2'
}

